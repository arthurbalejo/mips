#include <stdio.h>

void function();

void args6(int a, int b, int c, int d, int e, int f) {
	
	printf("a: %d\n",a);
	printf("b: %d\n",b);
	printf("c: %d\n",c);
	printf("d: %d\n",d);
	printf("e: %d\n",e);
	printf("f: %d\n",f);
}

int main() {

	function();
	
	return 0;
}